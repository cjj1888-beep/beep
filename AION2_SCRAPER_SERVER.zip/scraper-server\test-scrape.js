const puppeteer = require('puppeteer');

(async () => {
    const nickname = "부트띠"; // 테스트용 닉네임
    console.log(`🔍 '${nickname}' 정보 조회 시작 (Aion2Tool)...`);

    const browser = await puppeteer.launch({
        headless: "new",
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');

    try {
        const targetUrl = `https://aion2tool.com/char/serverid=1006/${encodeURIComponent(nickname)}`;
        await page.goto(targetUrl, { waitUntil: 'networkidle2' });

        // [핵심 수정] 단순 body 대기가 아니라, "전투력"이라는 글자가 뜰 때까지 기다림 (최대 15초)
        try {
            await page.waitForFunction(
                () => document.body.innerText.includes("전투력"),
                { timeout: 15000 }
            );
        } catch (e) {
            throw new Error("로딩 시간 초과 (데이터가 안 뜨거나 닉네임이 없음)");
        }

        const data = await page.evaluate(() => {
            const bodyText = document.body.innerText;
            return {
                raw: bodyText,
                lines: bodyText.split('\n').map(l => l.trim()).filter(l => l.length > 0)
            };
        });

        const raw = data.raw;
        const lines = data.lines;

        console.log("--- [DEBUG: 텍스트 구조] ---");
        // 상위 30줄 출력
        lines.slice(0, 30).forEach((line, i) => console.log(`[${i}] ${line}`));
        console.log("----------------------------");

        const jobs = ["수호성", "검성", "살성", "궁성", "마도성", "정령성", "치유성", "호법성"];
        const job = jobs.find(j => raw.includes(j)) || "미정";

        let power = 0;
        const powerMatch = raw.match(/전투력\s*([\d,]+)/);
        if (powerMatch) power = parseInt(powerMatch[1].replace(/,/g, ''));

        // [수정] 레기온 파싱 (츄 찾기)
        // 텍스트 라인에서 패턴 찾기
        let guild = "-";

        // 1. "레기온 이름"이 보통 레벨/직업 근처에 있음.
        // 라인을 순회하며 "레기온" 글자가 있는 줄 찾기
        /* 
           예상 구조:
           [10] 부트띠
           [11] 레벨 55
           [12] 츄 레기온
           [13] 아리엘
        */
        const legionLine = lines.find(l => l.includes('레기온') && !l.includes('전체') && !l.includes('필터'));
        if (legionLine) {
            // "츄 레기온" -> "츄" 추출
            const match = legionLine.match(/([^\s]+)\s*레기온/);
            if (match && match[1] !== '프' && match[1] !== '전체') {
                guild = match[1];
            } else {
                // "레기온 : 츄" 형태일 수도 있음
                const match2 = legionLine.match(/레기온\s*[:]?\s*([^\s]+)/);
                if (match2) guild = match2[1];
            }
        }

        // 2. 만약 위에서 못 찾았으면, "츄" 라는 단어가 단독으로 있는 줄이 있는지 확인 (혹시 모르니까)
        if (guild === "-" || guild === "프") {
            const chuLine = lines.find(l => l === "츄" || l === "츄 레기온");
            if (chuLine) guild = "츄";
        }

        let score = 0;
        const scoreMatch = raw.match(/(점수|Score|Level)\s*[:]?\s*([\d,]+)/i);
        if (scoreMatch) score = parseInt(scoreMatch[2].replace(/,/g, ''));

        console.log("------------------------------------------------");
        console.log(`✅ 이름: ${nickname}`);
        console.log(`✅ 레기온: ${guild}`);
        console.log(`✅ 직업: ${job}`);
        console.log(`✅ 전투력: ${power}`);
        console.log(`✅ 점수: ${score}`);
        console.log("------------------------------------------------");

    } catch (e) {
        console.error("❌ 실패:", e.message);
    } finally {
        await browser.close();
    }
})();
